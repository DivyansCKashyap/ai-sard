const DashboardPage = () => {
  return (
    <p>Dashboard Page (Protected ) </p>
  )
}

export default DashboardPage;