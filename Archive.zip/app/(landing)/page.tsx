const LandingPage = () => {
    return (
      <div>
        Landing Page (Unprotected)
      </div>
    );
}

export default LandingPage;